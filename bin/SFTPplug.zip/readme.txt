Secure FTP plugin (x64 only)
Copyright (C) Marek Wesolowski

Help:
- Open SFTPplug.chm for full documentation.
- You can also open help from the plugin connection dialog via the Help button.

Installation:
- Open this ZIP in Total Commander and press Enter on the archive.
- Confirm plugin installation when prompted.

Package contents:
- SFTPplug.wfx64 (x64 plugin binary)
- sftp.php (PHP Agent for HTTP transfer mode)
- pluginst.inf (TC auto-install descriptor)
- readme.txt

Important:
- This package is x64-only.
- No external libssh2.dll is required.
